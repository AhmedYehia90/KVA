KVA Pilot Dashboard Update

1. Copy:
apps/web/app/pilot/dashboard/page.tsx

2. Replace the existing file in your project.

3. Run:
pnpm build

4. Upload:
git add apps/web/app/pilot/dashboard/page.tsx
git commit -m "Connect pilot dashboard to Supabase"
git push origin main
